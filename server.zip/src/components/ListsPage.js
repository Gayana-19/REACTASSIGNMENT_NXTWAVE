import { useEffect, useState } from "react";
import { fetchLists } from "../services/api";
import { API_STATUS } from "../services/constants";
import Loader from "./Loader";
import ListContainer from "./components/ListContainer";
import "./ListsPage.css";

const ListsPage = ({ onCreateList }) => {
  const [lists, setLists] = useState([]);
  const [status, setStatus] = useState(API_STATUS.INITIAL);
  const [selectedLists, setSelectedLists] = useState([]);

  useEffect(() => {
    loadLists();
  }, []);

  const loadLists = async () => {
    setStatus(API_STATUS.LOADING);
    try {
      const data = await fetchLists();
      setLists(data.lists);
      setStatus(API_STATUS.SUCCESS);
    } catch {
      setStatus(API_STATUS.FAILURE);
    }
  };

  const toggleListSelection = (id) => {
    setSelectedLists((prev) =>
      prev.includes(id) ? prev.filter((l) => l !== id) : [...prev, id]
    );
  };

  return (
    <div className="lists-page">
      <h1>List Creation</h1>
      <button
        onClick={() => onCreateList(selectedLists)}
        disabled={selectedLists.length !== 2}
      >
        Create a new list
      </button>
      {status === API_STATUS.LOADING && <Loader />}
      {status === API_STATUS.FAILURE && (
        <div className="error-view">
          <p>Failed to load lists.</p>
          <button onClick={loadLists}>Try Again</button>
        </div>
      )}
      {status === API_STATUS.SUCCESS &&
        lists.map((list) => (
          <div key={list.id} className="list-wrapper">
            <input
              type="checkbox"
              onChange={() => toggleListSelection(list.id)}
              checked={selectedLists.includes(list.id)}
            />
            <ListContainer list={list} />
          </div>
        ))}
    </div>
  );
};

export default ListsPage;