import ListItem from "./ListItem";
import "./ListContainer.css";

const ListContainer = ({ list, moveItem }) => (
  <div className="list-container">
    <h3>{list.name}</h3>
    {list.items.map((item) => (
      <ListItem key={item.id} item={item} moveItem={moveItem} />
    ))}
  </div>
);

export default ListContainer;