import { useState } from "react";
import ListContainer from "./ListContainer";
import "./ListCreationPage.css";

const ListCreationPage = ({ selectedLists, lists, onCancel, onUpdate }) => {
  const [newList, setNewList] = useState({ id: "new", name: "New List", items: [] });

  const moveItem = (item, direction) => {
    setNewList((prev) => ({
      ...prev,
      items: direction === "right"
        ? [...prev.items, item]
        : prev.items.filter((i) => i.id !== item.id),
    }));
  };

  return (
    <div className="list-creation-page">
      <ListContainer list={lists[selectedLists[0]]} moveItem={moveItem} />
      <ListContainer list={newList} moveItem={moveItem} />
      <ListContainer list={lists[selectedLists[1]]} moveItem={moveItem} />
      <button onClick={onCancel}>Cancel</button>
      <button onClick={() => onUpdate(newList)}>Update</button>
    </div>
  );
};

export default ListCreationPage;