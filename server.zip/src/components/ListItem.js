import "./ListItem.css";

const ListItem = ({ item, moveItem }) => (
  <div className="list-item">
    <div className="item-content">
      <p className="item-title">{item.title}</p>
      <p className="item-subtitle">{item.subtitle}</p>
    </div>
    {moveItem && (
      <div className="item-actions">
        <button onClick={() => moveItem(item, "left")}>&larr;</button>
        <button onClick={() => moveItem(item, "right")}>&rarr;</button>
      </div>
    )}
  </div>
);

export default ListItem;