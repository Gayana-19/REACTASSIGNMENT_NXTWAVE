export const API_URL = "https://apis.ccbp.in/list-creation/lists";
export const API_STATUS = {
  INITIAL: "INITIAL",
  LOADING: "LOADING",
  SUCCESS: "SUCCESS",
  FAILURE: "FAILURE",
};