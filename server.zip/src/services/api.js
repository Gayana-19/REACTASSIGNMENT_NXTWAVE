import { API_URL } from "./constants";

export const fetchLists = async () => {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error("Failed to fetch");
    return await response.json();
  } catch (error) {
    throw error;
  }
};