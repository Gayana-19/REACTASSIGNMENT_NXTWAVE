import { useState } from "react";
import ListsPage from "./components/ListsPage";
import ListCreationPage from "./components/ListCreationPage";
import "./App.css";

const App = () => {
  const [view, setView] = useState("lists");
  const [selectedLists, setSelectedLists] = useState([]);
  const [lists, setLists] = useState([]);

  const handleCreateList = (selected) => {
    if (selected.length !== 2) {
      alert("You should select exactly 2 lists to create a new list");
      return;
    }
    setSelectedLists(selected);
    setView("creation");
  };

  const handleCancel = () => {
    setView("lists");
  };

  const handleUpdate = (newList) => {
    setLists((prev) => [...prev, newList]);
    setView("lists");
  };

  return (
    <div className="app">
      {view === "lists" ? (
        <ListsPage onCreateList={handleCreateList} />
      ) : (
        <ListCreationPage
          selectedLists={selectedLists}
          lists={lists}
          onCancel={handleCancel}
          onUpdate={handleUpdate}
        />
      )}
    </div>
  );
};

export default App;